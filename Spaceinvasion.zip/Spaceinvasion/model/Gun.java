package spaceinv.model;

public class Gun extends AbstractShootableObject {
    public Gun(double x, double y, double width, double height, double dx, double dy) {
        super(x, y, width, height, dx, dy);
    }

    @Override
    public void move() { // Necessary override b/c Gun should only move in x-direction.
        //x++; // Move ship left to right.
        // Correct way to move ship WITH WORKING INPUTS ... I think.
        this.x += this.dx;
    }
}
