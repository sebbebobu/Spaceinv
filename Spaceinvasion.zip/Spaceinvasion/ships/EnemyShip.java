package spaceinv.ships;

import spaceinv.model.AbstractShootableObject;

public class EnemyShip extends AbstractShootableObject {

    public EnemyShip(double x, double y, double width, double height, double dx, double dy) {
        super(x, y, width, height, dx, dy);
    }

    @Override
    public void move() {

    }
}
