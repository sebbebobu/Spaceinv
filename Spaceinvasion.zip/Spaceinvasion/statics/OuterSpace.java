package spaceinv.statics;

import spaceinv.model.AbstractGameObject;

public class OuterSpace extends AbstractGameObject {

    public OuterSpace(int x, int y, int width, int height) {
        this.height = height;
        this.width = width;
        this.x = x;
        this.y = y;
    }
    public boolean intersects(AbstractGameObject object) {
        if (object == null) {
            return false;
        }
        return ((object.y+object.height) < this.getMinY());
    }

}
