package spaceinv.statics;

import spaceinv.model.AbstractGameObject;

public class Ground extends AbstractGameObject {

    public Ground(double x, double y, double width, double height) {
        this.height = height;
        this.width = width;
        this.x = x;
        this.y = y;
    }
    public boolean intersects(AbstractGameObject object) {
        if (object == null) {
            return false;
        }
        return ((object.y+object.height) > this.getMinY());
    }

}
