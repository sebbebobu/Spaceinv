package spaceinv.test;

import spaceinv.model.AbstractShootableObject;

public class TestShip extends AbstractShootableObject {
    public TestShip(){
        super(0,150,40,108,0,0);
    }
}