package spaceinv.projectiles;

import spaceinv.model.AbstractMovableObject;

public class Bomb extends AbstractMovableObject {
    public Bomb(double x, double y, double width, double height,double dy) {
        super(x, y, width, height, 0, dy);
    }
}
